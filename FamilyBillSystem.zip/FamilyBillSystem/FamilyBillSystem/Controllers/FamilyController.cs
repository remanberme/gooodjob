using FamilyBillSystem.Data;
using FamilyBillSystem.DTOs;
using FamilyBillSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FamilyBillSystem.Controllers
{
    [Route("api/families")]
    [ApiController]
    [Authorize]
    public class FamilyController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<FamilyController> _logger;

        public FamilyController(AppDbContext context, ILogger<FamilyController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/families
        [HttpGet]
        public async Task<IActionResult> GetUserFamilies()
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var families = await _context.FamilyMembers
                    .Include(fm => fm.Family)
                        .ThenInclude(f => f.Creator)
                    .Include(fm => fm.Family)
                        .ThenInclude(f => f.Members)
                            .ThenInclude(m => m.User)
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => new
                    {
                        fm.Family.Id,
                        fm.Family.Name,
                        fm.Family.Description,
                        fm.Family.InviteCode,
                        fm.Family.CreatedAt,
                        Creator = new
                        {
                            fm.Family.Creator.Id,
                            fm.Family.Creator.Nickname,
                            fm.Family.Creator.AvatarUrl
                        },
                        MemberCount = fm.Family.Members.Count(m => m.Status == "active"),
                        Role = fm.Role,
                        JoinedAt = fm.JoinedAt
                    })
                    .ToListAsync();

                return Ok(new { data = families });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取用户家庭列表失败");
                return StatusCode(500, new { message = "获取家庭列表失败" });
            }
        }

        // POST: api/families
        [HttpPost]
        public async Task<IActionResult> CreateFamily([FromBody] CreateFamilyRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                if (string.IsNullOrWhiteSpace(request.Name))
                    return BadRequest(new { message = "家庭名称不能为空" });

                // 生成邀请码
                var inviteCode = GenerateInviteCode();

                var family = new Family
                {
                    Name = request.Name,
                    Description = request.Description ?? "",
                    InviteCode = inviteCode,
                    CreatorId = userId.Value,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Families.Add(family);
                await _context.SaveChangesAsync();

                // 创建者自动成为管理员
                var memberRecord = new FamilyMember
                {
                    FamilyId = family.Id,
                    UserId = userId.Value,
                    Role = "admin",
                    Status = "active",
                    JoinedAt = DateTime.Now,
                    Nickname = request.CreatorNickname ?? "管理员"
                };

                _context.FamilyMembers.Add(memberRecord);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "家庭创建成功",
                    data = new
                    {
                        family.Id,
                        family.Name,
                        family.Description,
                        family.InviteCode,
                        family.CreatedAt
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "创建家庭失败");
                return StatusCode(500, new { message = "创建家庭失败" });
            }
        }

        // POST: api/families/join
        [HttpPost("join")]
        public async Task<IActionResult> JoinFamily([FromBody] JoinFamilyRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                if (string.IsNullOrWhiteSpace(request.InviteCode))
                    return BadRequest(new { message = "邀请码不能为空" });

                var family = await _context.Families
                    .FirstOrDefaultAsync(f => f.InviteCode == request.InviteCode && f.DeletedAt == null);

                if (family == null)
                    return BadRequest(new { message = "邀请码无效" });

                // 检查是否已经是成员
                var existingMember = await _context.FamilyMembers
                    .FirstOrDefaultAsync(fm => fm.FamilyId == family.Id && fm.UserId == userId);

                if (existingMember != null)
                {
                    if (existingMember.Status == "active")
                        return BadRequest(new { message = "您已经是该家庭的成员" });
                    
                    // 重新激活成员
                    existingMember.Status = "active";
                    existingMember.JoinedAt = DateTime.Now;
                    existingMember.Nickname = request.Nickname ?? "成员";
                }
                else
                {
                    // 创建新成员记录
                    var memberRecord = new FamilyMember
                    {
                        FamilyId = family.Id,
                        UserId = userId.Value,
                        Role = "member",
                        Status = "active",
                        JoinedAt = DateTime.Now,
                        Nickname = request.Nickname ?? "成员"
                    };

                    _context.FamilyMembers.Add(memberRecord);
                }

                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "加入家庭成功",
                    data = new
                    {
                        family.Id,
                        family.Name,
                        family.Description
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "加入家庭失败");
                return StatusCode(500, new { message = "加入家庭失败" });
            }
        }

        // GET: api/families/{id}/members
        [HttpGet("{id}/members")]
        public async Task<IActionResult> GetFamilyMembers(int id)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                // 验证用户是否是该家庭成员
                var isMember = await _context.FamilyMembers
                    .AnyAsync(fm => fm.FamilyId == id && fm.UserId == userId && fm.Status == "active");

                if (!isMember)
                    return Forbid("您不是该家庭的成员");

                var members = await _context.FamilyMembers
                    .Include(fm => fm.User)
                    .Where(fm => fm.FamilyId == id && fm.Status == "active")
                    .Select(fm => new
                    {
                        fm.Id,
                        fm.UserId,
                        fm.Nickname,
                        fm.Role,
                        fm.JoinedAt,
                        User = new
                        {
                            fm.User.Id,
                            fm.User.Nickname,
                            fm.User.AvatarUrl,
                            fm.User.Email
                        }
                    })
                    .ToListAsync();

                return Ok(new { data = members });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取家庭成员失败");
                return StatusCode(500, new { message = "获取家庭成员失败" });
            }
        }

        // DELETE: api/families/{id}/leave
        [HttpDelete("{id}/leave")]
        public async Task<IActionResult> LeaveFamily(int id)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var member = await _context.FamilyMembers
                    .Include(fm => fm.Family)
                    .FirstOrDefaultAsync(fm => fm.FamilyId == id && fm.UserId == userId && fm.Status == "active");

                if (member == null)
                    return BadRequest(new { message = "您不是该家庭的成员" });

                // 检查是否是创建者
                if (member.Family.CreatorId == userId)
                {
                    // 检查是否还有其他成员
                    var otherMembersCount = await _context.FamilyMembers
                        .CountAsync(fm => fm.FamilyId == id && fm.UserId != userId && fm.Status == "active");

                    if (otherMembersCount > 0)
                        return BadRequest(new { message = "作为创建者，请先转让管理权或删除家庭" });
                }

                member.Status = "left";
                member.LeftAt = DateTime.Now;

                await _context.SaveChangesAsync();

                return Ok(new { message = "已退出家庭" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "退出家庭失败");
                return StatusCode(500, new { message = "退出家庭失败" });
            }
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
            {
                return userId;
            }
            return null;
        }

        private string GenerateInviteCode()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, 6)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }

    public class CreateFamilyRequest
    {
        public string Name { get; set; } = "";
        public string? Description { get; set; }
        public string? CreatorNickname { get; set; }
    }

    public class JoinFamilyRequest
    {
        public string InviteCode { get; set; } = "";
        public string? Nickname { get; set; }
    }
}
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;

namespace FamilyBillSystem.Services
{
    public class EmailService
    {
        private readonly EmailSettings _emailSettings;
        private readonly Dictionary<string, (string Code, DateTime ExpireTime)> _verificationCodes = new();

        public EmailService(IOptions<EmailSettings> emailSettings)
        {
            _emailSettings = emailSettings.Value;
        }

        public async Task SendVerificationCodeAsync(string toEmail, string code)
        {
            var subject = "【家庭账单管理】注册邮箱验证码";
            var body = $@"
                <div style='font-family: Arial, sans-serif; padding: 20px;'>
                    <h2 style='color: #4CAF50;'>家庭账单管理系统</h2>
                    <p>你正在注册账号，验证码为：</p>
                    <p style='font-size: 24px; font-weight: bold; color: #4CAF50; letter-spacing: 5px;'>{code}</p>
                    <p style='color: #666;'>验证码有效期为 5 分钟，请勿泄露给他人。</p>
                    <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'/>
                    <p style='color: #999; font-size: 12px;'>如果这不是你的操作，请忽略此邮件。</p>
                </div>
            ";

            using (var client = new SmtpClient(_emailSettings.SmtpServer, _emailSettings.SmtpPort))
            {
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential(
                    _emailSettings.SmtpUsername,
                    _emailSettings.SmtpPassword
                );

                var message = new MailMessage(
                    from: new MailAddress(_emailSettings.SmtpUsername, _emailSettings.SenderName),
                    to: new MailAddress(toEmail)
                )
                {
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };

                await client.SendMailAsync(message);
            }

            _verificationCodes[toEmail] = (code, DateTime.Now.AddMinutes(5));
        }

        public string GenerateVerificationCode()
        {
            var random = new Random();
            return random.Next(100000, 999999).ToString();
        }

        public bool VerifyCode(string email, string code)
        {
            if (!_verificationCodes.TryGetValue(email, out var storedData))
                return false;

            if (DateTime.Now > storedData.ExpireTime)
            {
                _verificationCodes.Remove(email);
                return false;
            }

            if (storedData.Code != code)
                return false;

            _verificationCodes.Remove(email);
            return true;
        }
    }

    public class EmailSettings
    {
        public string SmtpServer { get; set; }
        public int SmtpPort { get; set; }
        public string SmtpUsername { get; set; }
        public string SmtpPassword { get; set; }
        public string SenderName { get; set; }
    }
}

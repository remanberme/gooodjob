// app.js
App({
  globalData: {
    userInfo: null,
    token: null,
    refreshToken: null,
    baseUrl: 'https://corpus-insider-harvey-communities.trycloudflare.com/api',
    currentFamily: null,
    categories: [],
    systemInfo: null,
    isRefreshingToken: false,
    requestQueue: []
  },

  onLaunch() {
    wx.getSystemInfo({
      success: (res) => {
        this.globalData.systemInfo = res;
      }
    });
    this.checkLoginStatus();
  },

  checkLoginStatus() {
    const token = wx.getStorageSync('token');
    const refreshToken = wx.getStorageSync('refreshToken');
    const userInfo = wx.getStorageSync('userInfo');
    
    console.log('[checkLoginStatus] 从storage读取Token:', token ? `${token.length}字符` : '不存在');
    console.log('[checkLoginStatus] 从storage读取RefreshToken:', refreshToken ? `${refreshToken.length}字符` : '不存在');
    console.log('[checkLoginStatus] 从storage读取UserInfo:', userInfo ? userInfo.nickname : '不存在');

    if (token && refreshToken && userInfo) {
      this.globalData.token = token;
      this.globalData.refreshToken = refreshToken;
      this.globalData.userInfo = userInfo;
      console.log('[checkLoginStatus] 已恢复Token和RefreshToken到globalData');
    } else {
      console.log('[checkLoginStatus] Token/RefreshToken/UserInfo不完整，清空数据');
      this.clearAuthData();
    }
  },

  clearAuthData() {
    this.globalData.token = null;
    this.globalData.refreshToken = null;
    this.globalData.userInfo = null;
    this.globalData.currentFamily = null;
    wx.removeStorageSync('token');
    wx.removeStorageSync('refreshToken');
    wx.removeStorageSync('userInfo');
    wx.removeStorageSync('currentFamily');
  },


  async login(loginData) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: `${this.globalData.baseUrl}/auth/wechat-login`,
        method: 'POST',
        data: loginData,
        header: { 'Content-Type': 'application/json' },
        success: (res) => {
          if (res.statusCode === 200 && res.data.token && res.data.refreshToken && res.data.user) {
            const { token, refreshToken, user } = res.data;
            console.log('[登录成功] Token长度:', token.length, 'RefreshToken长度:', refreshToken.length, 'UserInfo:', user);
            this.globalData.token = token;
            this.globalData.refreshToken = refreshToken;
            this.globalData.userInfo = user;
            wx.setStorageSync('token', token);
            wx.setStorageSync('refreshToken', refreshToken);
            wx.setStorageSync('userInfo', user);
            resolve(res.data);
          } else {
            reject(res.data || { message: '登录失败' });
          }
        },
        fail: (err) => reject(err)
      });
    });
  },

  logout() {
    console.log('[logout] 被调用，清空所有数据');
    console.trace('[logout] 调用堆栈');
    this.clearAuthData();
    wx.reLaunch({ url: '/pages/login/login' });
  },

  async request(options) {
    return new Promise((resolve, reject) => {
      const url = `${this.globalData.baseUrl}${options.url}`;
      
      const headers = {
        'Content-Type': 'application/json',
        ...options.header
      };
      
      // 只在有token时添加Authorization头
      if (this.globalData.token) {
        console.log(`[request] URL: ${options.url}, Token长度: ${this.globalData.token.length}, Token前20字符: ${this.globalData.token.substring(0, 20)}`);
        headers['Authorization'] = `Bearer ${this.globalData.token}`;
      } else {
        console.log(`[request] URL: ${options.url}, 无Token`);
      }

      wx.request({
        url,
        method: options.method || 'GET',
        data: options.data || {},
        header: headers,
        success: async (res) => {
          if (res.statusCode === 200) {
            return resolve(res.data);
          }

          // Token过期，尝试刷新
          if (res.statusCode === 401 && !options._isRetry) {
            console.log('[request] 收到401，尝试刷新Token');
            try {
              await this.handleTokenRefresh();
              // 刷新成功，重试请求（标记为重试避免无限循环）
              options._isRetry = true;
              const retryRes = await this.request(options);
              resolve(retryRes);
            } catch (err) {
              console.error('[request] Token刷新失败:', err);
              this.logout();
              reject({ message: '登录已过期，请重新登录' });
            }
            return;
          }

          reject(res.data || { message: '请求失败' });
        },
        fail: (err) => {
          reject({ message: err.errMsg || '网络请求失败' });
        }
      });
    });
  },

  async handleTokenRefresh() {
    // 防止并发刷新
    if (this.globalData.isRefreshingToken) {
      return new Promise((resolve, reject) => {
        const checkInterval = setInterval(() => {
          if (!this.globalData.isRefreshingToken) {
            clearInterval(checkInterval);
            if (this.globalData.token) {
              resolve();
            } else {
              reject(new Error('Token刷新失败'));
            }
          }
        }, 100);
        
        // 最多等待10秒
        setTimeout(() => {
          clearInterval(checkInterval);
          reject(new Error('Token刷新超时'));
        }, 10000);
      });
    }

    this.globalData.isRefreshingToken = true;
    console.log('[handleTokenRefresh] 开始刷新Token');
    
    try {
      const refreshToken = this.globalData.refreshToken;
      
      if (!refreshToken) {
        throw new Error('RefreshToken不存在，请重新登录');
      }

      const refreshRes = await new Promise((resolve, reject) => {
        wx.request({
          url: `${this.globalData.baseUrl}/auth/refresh-token`,
          method: 'POST',
          data: { refreshToken },
          header: { 'Content-Type': 'application/json' },
          success: (res) => {
            if (res.statusCode === 200 && res.data.token && res.data.refreshToken) {
              resolve(res.data);
            } else {
              reject(new Error(res.data?.message || '刷新Token失败'));
            }
          },
          fail: (err) => reject(new Error(err.errMsg || '网络请求失败'))
        });
      });

      // 更新Token
      this.globalData.token = refreshRes.token;
      this.globalData.refreshToken = refreshRes.refreshToken;
      this.globalData.userInfo = refreshRes.user;
      
      wx.setStorageSync('token', refreshRes.token);
      wx.setStorageSync('refreshToken', refreshRes.refreshToken);
      wx.setStorageSync('userInfo', refreshRes.user);
      
      console.log('[handleTokenRefresh] Token刷新成功');
    } catch (err) {
      console.error('[handleTokenRefresh] Token刷新失败:', err);
      this.clearAuthData();
      throw err;
    } finally {
      this.globalData.isRefreshingToken = false;
    }
  },

  // UI 辅助函数
  showLoading(title = '加载中...') { wx.showLoading({ title, mask: true }); },
  hideLoading() { wx.hideLoading(); },
  showToast(title, icon = 'none', duration = 2000) { wx.showToast({ title, icon, duration }); },
  showModal(title, content) {
    return new Promise((resolve) => wx.showModal({ title, content, success: res => resolve(res.confirm) }));
  },

  // 工具函数
  formatDate(date, format = 'YYYY-MM-DD') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hour = String(d.getHours()).padStart(2, '0');
    const minute = String(d.getMinutes()).padStart(2, '0');
    const second = String(d.getSeconds()).padStart(2, '0');
    return format.replace('YYYY', year).replace('MM', month).replace('DD', day)
                 .replace('HH', hour).replace('mm', minute).replace('ss', second);
  },

  formatAmount(amount) { return parseFloat(amount).toFixed(2); },
  
  // 日志工具
  log: {
    debug: function(...args) {
      if (__wxConfig && __wxConfig.debug) {
        console.debug('[DEBUG]', ...args);
      }
    },
    info: function(...args) {
      console.log('[INFO]', ...args);
    },
    error: function(...args) {
      console.error('[ERROR]', ...args);
      // 可以在这里添加错误上报逻辑
    }
  }
});

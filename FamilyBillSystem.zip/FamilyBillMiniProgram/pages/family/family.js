// pages/family/family.js
const app = getApp();

Page({
  data: {
    currentFamily: null,
    familyMembers: [],
    myFamilies: [],
    budgetSummary: null,
    inviteCode: '',
    
    // 弹窗状态
    showCreateFamilyModal: false,
    showJoinFamilyModal: false,
    showInviteModal: false,
    showFamilyActions: false,
    
    // 表单数据
    createForm: {
      name: '',
      description: ''
    },
    joinForm: {
      inviteCode: ''
    },
    
    // 加载状态
    createLoading: false,
    joinLoading: false
  },

  onLoad() {
    // 从缓存获取当前家庭
    const currentFamily = wx.getStorageSync('currentFamily');
    if (currentFamily) {
      this.setData({ currentFamily });
    }
  },

  onShow() {
    if (!app.globalData.token) {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }
    
    this.loadData();
  },

  // 加载数据
  async loadData() {
    try {
      await Promise.all([
        this.loadMyFamilies(),
        this.loadCurrentFamilyData()
      ]);
    } catch (error) {
      console.error('加载家庭数据失败:', error);
    }
  },

  // 加载我的家庭列表
  async loadMyFamilies() {
    try {
      const res = await app.request({
        url: '/families/my-families'
      });
      
      this.setData({
        myFamilies: res || []
      });
    } catch (error) {
      console.error('加载家庭列表失败:', error);
    }
  },

  // 加载当前家庭数据
  async loadCurrentFamilyData() {
    const { currentFamily } = this.data;
    if (!currentFamily) return;
    
    try {
      await Promise.all([
        this.loadFamilyMembers(),
        this.loadBudgetSummary()
      ]);
    } catch (error) {
      console.error('加载当前家庭数据失败:', error);
    }
  },

  // 加载家庭成员
  async loadFamilyMembers() {
    try {
      const res = await app.request({
        url: `/families/${this.data.currentFamily.id}/members`
      });
      
      const members = (res || []).map(member => ({
        ...member,
        joinDate: app.formatDate(member.joinDate, 'YYYY-MM-DD')
      }));
      
      this.setData({
        familyMembers: members
      });
    } catch (error) {
      console.error('加载家庭成员失败:', error);
    }
  },

  // 加载预算概览
  async loadBudgetSummary() {
    try {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      
      const res = await app.request({
        url: `/budgets/summary?year=${year}&month=${month}&familyId=${this.data.currentFamily.id}`
      });
      
      if (res && res.budgets && res.budgets.length > 0) {
        const totalBudget = res.budgets.reduce((sum, item) => sum + item.amount, 0);
        const totalUsed = res.budgets.reduce((sum, item) => sum + item.usedAmount, 0);
        const remaining = totalBudget - totalUsed;
        const usagePercentage = totalBudget > 0 ? Math.round((totalUsed / totalBudget) * 100) : 0;
        
        this.setData({
          budgetSummary: {
            totalBudget: app.formatAmount(totalBudget),
            totalUsed: app.formatAmount(totalUsed),
            remaining: app.formatAmount(remaining),
            usagePercentage
          }
        });
      }
    } catch (error) {
      console.error('加载预算概览失败:', error);
    }
  },

  // 切换家庭
  async switchFamily(e) {
    const family = e.currentTarget.dataset.family;
    
    if (family.id === this.data.currentFamily?.id) return;
    
    try {
      app.showLoading('切换中...');
      
      // 保存到全局数据和本地存储
      app.globalData.currentFamily = family;
      wx.setStorageSync('currentFamily', family);
      
      this.setData({
        currentFamily: family
      });
      
      // 重新加载当前家庭数据
      await this.loadCurrentFamilyData();
      
      app.showToast('切换成功', 'success');
    } catch (error) {
      console.error('切换家庭失败:', error);
      app.showToast('切换失败，请重试');
    } finally {
      app.hideLoading();
    }
  },

  // 显示创建家庭弹窗
  showCreateFamilyModal() {
    this.setData({
      showCreateFamilyModal: true,
      createForm: {
        name: '',
        description: ''
      }
    });
  },

  // 隐藏创建家庭弹窗
  hideCreateFamilyModal() {
    this.setData({
      showCreateFamilyModal: false
    });
  },

  // 创建家庭表单输入
  onCreateNameInput(e) {
    this.setData({
      'createForm.name': e.detail.value
    });
  },

  onCreateDescriptionInput(e) {
    this.setData({
      'createForm.description': e.detail.value
    });
  },

  // 创建家庭
  async createFamily() {
    const { createForm } = this.data;
    
    if (!createForm.name.trim()) {
      app.showToast('请输入家庭名称');
      return;
    }
    
    this.setData({ createLoading: true });
    
    try {
      const familyData = {
        name: createForm.name.trim(),
        description: createForm.description.trim() || null
      };
      
      const res = await app.request({
        url: '/families',
        method: 'POST',
        data: familyData
      });
      
      // 设置为当前家庭
      app.globalData.currentFamily = res;
      wx.setStorageSync('currentFamily', res);
      
      this.setData({
        currentFamily: res,
        showCreateFamilyModal: false
      });
      
      // 重新加载数据
      await this.loadData();
      
      app.showToast('家庭创建成功', 'success');
    } catch (error) {
      console.error('创建家庭失败:', error);
      app.showToast(error.message || '创建失败，请重试');
    } finally {
      this.setData({ createLoading: false });
    }
  },

  // 显示加入家庭弹窗
  showJoinFamilyModal() {
    this.setData({
      showJoinFamilyModal: true,
      joinForm: {
        inviteCode: ''
      }
    });
  },

  // 隐藏加入家庭弹窗
  hideJoinFamilyModal() {
    this.setData({
      showJoinFamilyModal: false
    });
  },

  // 加入家庭表单输入
  onJoinCodeInput(e) {
    this.setData({
      'joinForm.inviteCode': e.detail.value.toUpperCase()
    });
  },

  // 加入家庭
  async joinFamily() {
    const { joinForm } = this.data;
    
    if (!joinForm.inviteCode.trim()) {
      app.showToast('请输入邀请码');
      return;
    }
    
    if (joinForm.inviteCode.length !== 6) {
      app.showToast('邀请码应为6位');
      return;
    }
    
    this.setData({ joinLoading: true });
    
    try {
      const res = await app.request({
        url: '/families/join',
        method: 'POST',
        data: {
          inviteCode: joinForm.inviteCode.trim()
        }
      });
      
      // 设置为当前家庭
      app.globalData.currentFamily = res;
      wx.setStorageSync('currentFamily', res);
      
      this.setData({
        currentFamily: res,
        showJoinFamilyModal: false
      });
      
      // 重新加载数据
      await this.loadData();
      
      app.showToast('加入家庭成功', 'success');
    } catch (error) {
      console.error('加入家庭失败:', error);
      app.showToast(error.message || '加入失败，请检查邀请码');
    } finally {
      this.setData({ joinLoading: false });
    }
  },

  // 显示邀请弹窗
  async showInviteModal() {
    try {
      app.showLoading('生成邀请码...');
      
      const res = await app.request({
        url: `/families/${this.data.currentFamily.id}/invite-code`,
        method: 'POST'
      });
      
      this.setData({
        inviteCode: res.inviteCode,
        showInviteModal: true
      });
    } catch (error) {
      console.error('生成邀请码失败:', error);
      app.showToast('生成邀请码失败');
    } finally {
      app.hideLoading();
    }
  },

  // 隐藏邀请弹窗
  hideInviteModal() {
    this.setData({
      showInviteModal: false
    });
  },

  // 复制邀请码
  copyInviteCode() {
    wx.setClipboardData({
      data: this.data.inviteCode,
      success: () => {
        app.showToast('邀请码已复制', 'success');
      }
    });
  },

  // 分享邀请码
  shareInviteCode() {
    const { inviteCode, currentFamily } = this.data;
    
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
    
    // 这里可以实现分享逻辑
    app.showToast('请通过复制邀请码的方式分享');
  },

  // 显示家庭操作
  showFamilyActions() {
    this.setData({
      showFamilyActions: true
    });
  },

  // 隐藏家庭操作
  hideFamilyActions() {
    this.setData({
      showFamilyActions: false
    });
  },

  // 编辑家庭
  editFamily() {
    this.hideFamilyActions();
    wx.navigateTo({
      url: `/pages/edit-family/edit-family?id=${this.data.currentFamily.id}`
    });
  },

  // 预算管理
  manageBudget() {
    this.hideFamilyActions();
    wx.navigateTo({
      url: '/pages/budget/budget'
    });
  },

  // 成员管理
  manageMembers() {
    this.hideFamilyActions();
    wx.navigateTo({
      url: `/pages/family-members/family-members?familyId=${this.data.currentFamily.id}`
    });
  },

  // 退出家庭
  async leaveFamily() {
    const confirmed = await app.showModal('确认退出', '确定要退出当前家庭吗？退出后将无法查看家庭账单。');
    if (!confirmed) return;
    
    this.hideFamilyActions();
    
    try {
      app.showLoading('退出中...');
      
      await app.request({
        url: `/families/${this.data.currentFamily.id}/leave`,
        method: 'POST'
      });
      
      // 清除当前家庭
      app.globalData.currentFamily = null;
      wx.removeStorageSync('currentFamily');
      
      this.setData({
        currentFamily: null,
        familyMembers: [],
        budgetSummary: null
      });
      
      // 重新加载家庭列表
      await this.loadMyFamilies();
      
      app.showToast('已退出家庭', 'success');
    } catch (error) {
      console.error('退出家庭失败:', error);
      app.showToast('退出失败，请重试');
    } finally {
      app.hideLoading();
    }
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadData().finally(() => {
      wx.stopPullDownRefresh();
    });
  },
  
  // 头像加载失败处理
  onAvatarLoadError(e) {
    console.log('头像加载失败，使用默认头像', e);
    const { index } = e.currentTarget.dataset;
    const updatePath = index !== undefined 
      ? `familyMembers[${index}].avatar`
      : 'userInfo.avatar';
      
    this.setData({
      [updatePath]: '/images/user.png'
    });
  }
});
// pages/budget/budget.js
const app = getApp();

Page({
  data: {
    // 时间选择
    selectedYear: new Date().getFullYear(),
    selectedMonth: new Date().getMonth() + 1,
    
    // 预算数据
    budgets: [],
    totalBudget: '0.00',
    totalUsed: '0.00',
    totalRemaining: '0.00',
    
    // 分类数据
    expenseCategories: [],
    selectedCategory: null,
    
    // 弹窗状态
    showTimePicker: false,
    showBudgetModal: false,
    showCategoryPicker: false,
    
    // 表单数据
    budgetForm: {
      id: null,
      categoryId: null,
      amount: '',
      description: ''
    },
    isEditMode: false,
    
    // 时间选择器
    years: [],
    months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    timePickerValue: [0, 0],
    
    // 加载状态
    saveLoading: false
  },

  onLoad() {
    this.initTimePicker();
    this.loadExpenseCategories();
  },

  onShow() {
    if (!app.globalData.token) {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }
    
    this.loadBudgets();
  },

  // 初始化时间选择器
  initTimePicker() {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - 2; i <= currentYear + 2; i++) {
      years.push(i);
    }
    
    const yearIndex = years.indexOf(this.data.selectedYear);
    const monthIndex = this.data.selectedMonth - 1;
    
    this.setData({
      years,
      timePickerValue: [yearIndex, monthIndex]
    });
  },

  // 加载支出分类
  async loadExpenseCategories() {
    try {
      const res = await app.request({
        url: '/categories?type=2' // 支出分类
      });
      
      this.setData({
        expenseCategories: res || []
      });
    } catch (error) {
      console.error('加载分类失败:', error);
    }
  },

  // 加载预算数据
  async loadBudgets() {
    try {
      const { selectedYear, selectedMonth } = this.data;
      const familyId = app.globalData.currentFamily?.id;
      
      let url = `/budgets?year=${selectedYear}&month=${selectedMonth}`;
      if (familyId) {
        url += `&familyId=${familyId}`;
      }
      
      const res = await app.request({ url });
      
      const budgets = (res || []).map(budget => {
        const remaining = budget.amount - budget.usedAmount;
        const usagePercentage = budget.amount > 0 ? Math.round((budget.usedAmount / budget.amount) * 100) : 0;
        
        return {
          ...budget,
          amount: app.formatAmount(budget.amount),
          usedAmount: app.formatAmount(budget.usedAmount),
          remaining: app.formatAmount(remaining),
          usagePercentage,
          isOverBudget: budget.usedAmount > budget.amount
        };
      });
      
      // 计算总计
      const totalBudget = budgets.reduce((sum, item) => sum + parseFloat(item.amount), 0);
      const totalUsed = budgets.reduce((sum, item) => sum + parseFloat(item.usedAmount), 0);
      const totalRemaining = totalBudget - totalUsed;
      
      this.setData({
        budgets,
        totalBudget: app.formatAmount(totalBudget),
        totalUsed: app.formatAmount(totalUsed),
        totalRemaining: app.formatAmount(totalRemaining)
      });
    } catch (error) {
      console.error('加载预算失败:', error);
      app.showToast('加载预算失败');
    }
  },

  // 计算时间显示文本
  get timeText() {
    const { selectedYear, selectedMonth } = this.data;
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1;
    
    if (selectedYear === currentYear && selectedMonth === currentMonth) {
      return '本月预算';
    }
    return `${selectedYear}年${selectedMonth}月预算`;
  },

  // 显示时间选择器
  showTimePicker() {
    this.setData({ showTimePicker: true });
  },

  // 隐藏时间选择器
  hideTimePicker() {
    this.setData({ showTimePicker: false });
  },

  // 时间选择器变化
  onTimePickerChange(e) {
    this.setData({
      timePickerValue: e.detail.value
    });
  },

  // 确认时间选择
  confirmTimePicker() {
    const { years, months, timePickerValue } = this.data;
    const selectedYear = years[timePickerValue[0]];
    const selectedMonth = months[timePickerValue[1]];
    
    this.setData({
      selectedYear,
      selectedMonth,
      showTimePicker: false
    });
    
    this.loadBudgets();
  },

  // 显示添加预算弹窗
  showAddBudgetModal() {
    this.setData({
      showBudgetModal: true,
      isEditMode: false,
      budgetForm: {
        id: null,
        categoryId: null,
        amount: '',
        description: ''
      },
      selectedCategory: null
    });
  },

  // 编辑预算
  editBudget(e) {
    const budget = e.currentTarget.dataset.budget;
    const category = this.data.expenseCategories.find(cat => cat.id === budget.categoryId);
    
    this.setData({
      showBudgetModal: true,
      isEditMode: true,
      budgetForm: {
        id: budget.id,
        categoryId: budget.categoryId,
        amount: parseFloat(budget.amount).toString(),
        description: budget.description || ''
      },
      selectedCategory: category
    });
  },

  // 隐藏预算弹窗
  hideBudgetModal() {
    this.setData({
      showBudgetModal: false
    });
  },

  // 显示分类选择器
  showCategoryPicker() {
    this.setData({
      showCategoryPicker: true
    });
  },

  // 隐藏分类选择器
  hideCategoryPicker() {
    this.setData({
      showCategoryPicker: false
    });
  },

  // 选择分类
  selectCategory(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({
      'budgetForm.categoryId': category.id,
      selectedCategory: category
    });
  },

  // 预算表单输入
  onBudgetAmountInput(e) {
    this.setData({
      'budgetForm.amount': e.detail.value
    });
  },

  onBudgetDescriptionInput(e) {
    this.setData({
      'budgetForm.description': e.detail.value
    });
  },

  // 保存预算
  async saveBudget() {
    const { budgetForm, selectedYear, selectedMonth, isEditMode } = this.data;
    
    if (!budgetForm.categoryId) {
      app.showToast('请选择分类');
      return;
    }
    
    if (!budgetForm.amount || parseFloat(budgetForm.amount) <= 0) {
      app.showToast('请输入有效的预算金额');
      return;
    }
    
    this.setData({ saveLoading: true });
    
    try {
      const budgetData = {
        categoryId: budgetForm.categoryId,
        amount: parseFloat(budgetForm.amount),
        year: selectedYear,
        month: selectedMonth,
        description: budgetForm.description.trim() || null
      };
      
      // 如果有当前家庭，添加家庭ID
      if (app.globalData.currentFamily) {
        budgetData.familyId = app.globalData.currentFamily.id;
      }
      
      if (isEditMode) {
        await app.request({
          url: `/budgets/${budgetForm.id}`,
          method: 'PUT',
          data: budgetData
        });
        app.showToast('预算更新成功', 'success');
      } else {
        await app.request({
          url: '/budgets',
          method: 'POST',
          data: budgetData
        });
        app.showToast('预算添加成功', 'success');
      }
      
      this.hideBudgetModal();
      this.loadBudgets();
    } catch (error) {
      console.error('保存预算失败:', error);
      app.showToast(error.message || '保存失败，请重试');
    } finally {
      this.setData({ saveLoading: false });
    }
  },

  // 删除预算
  async deleteBudget(e) {
    const id = e.currentTarget.dataset.id;
    
    const confirmed = await app.showModal('确认删除', '确定要删除这个预算吗？');
    if (!confirmed) return;
    
    try {
      app.showLoading('删除中...');
      
      await app.request({
        url: `/budgets/${id}`,
        method: 'DELETE'
      });
      
      app.showToast('预算删除成功', 'success');
      this.loadBudgets();
    } catch (error) {
      console.error('删除预算失败:', error);
      app.showToast('删除失败，请重试');
    } finally {
      app.hideLoading();
    }
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadBudgets().finally(() => {
      wx.stopPullDownRefresh();
    });
  }
});
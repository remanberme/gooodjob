# 家庭账单管理系统 - 微信小程序

这是一个基于微信小程序的家庭账单管理系统前端，配合ASP.NET Core后端API使用。

## 功能特性

### 🔐 用户管理
- 微信授权登录
- 用户注册和身份验证
- 个人信息管理
- 头像上传

### 🏠 家庭管理
- 创建和加入家庭
- 家庭成员管理
- 邀请码分享
- 家庭切换

### 📝 账单管理
- 添加收入/支出账单
- 账单分类管理
- 账单查询和筛选
- 账单编辑和删除

### 📊 统计分析
- 收支统计图表
- 分类统计分析
- 趋势分析
- 月度/年度报表

### 💰 预算管理
- 分类预算设置
- 预算执行监控
- 超支提醒
- 预算分析

### 📤 数据管理
- 账单数据导出
- Excel/CSV格式支持
- 数据备份

## 技术栈

- **前端框架**: 微信小程序原生开发
- **UI组件**: 自定义组件库
- **状态管理**: 全局数据管理
- **网络请求**: 封装的HTTP请求库
- **图表展示**: Canvas绘制

## 项目结构

```
FamilyBillMiniProgram/
├── app.js                 # 小程序入口文件
├── app.json               # 小程序配置文件
├── app.wxss               # 全局样式文件
├── project.config.json    # 项目配置文件
├── sitemap.json          # 站点地图配置
├── pages/                # 页面目录
│   ├── index/            # 首页
│   ├── login/            # 登录页
│   ├── bills/            # 账单列表
│   ├── add-bill/         # 添加账单
│   ├── statistics/       # 统计分析
│   ├── family/           # 家庭管理
│   ├── profile/          # 个人中心
│   ├── categories/       # 分类管理
│   └── budget/           # 预算管理
├── utils/                # 工具函数
├── components/           # 自定义组件
└── images/               # 图片资源
```

## 安装和运行

### 前置要求

1. 安装微信开发者工具
2. 注册微信小程序账号
3. 配置后端API服务

### 配置步骤

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd FamilyBillMiniProgram
   ```

2. **配置API地址**
   
   在 `app.js` 中修改后端API地址：
   ```javascript
   globalData: {
     baseUrl: 'https://your-api-domain.com/api', // 修改为你的API地址
     // ...
   }
   ```

3. **配置微信小程序**
   
   在 `project.config.json` 中配置你的小程序AppID：
   ```json
   {
     "appid": "your-miniprogram-appid",
     // ...
   }
   ```

4. **导入项目**
   
   使用微信开发者工具导入项目目录

5. **编译运行**
   
   在微信开发者工具中编译并预览

## 配置说明

### API配置

在 `app.js` 中配置后端API相关参数：

```javascript
globalData: {
  baseUrl: 'https://your-api-domain.com/api',
  timeout: 10000,
  token: null,
  userInfo: null,
  currentFamily: null
}
```

### 微信登录配置

确保后端API支持微信小程序登录，需要配置：
- 微信小程序AppID和AppSecret
- 微信登录接口 `/auth/wechat-login`

## 主要页面说明

### 首页 (index)
- 显示账单概览
- 快速添加账单
- 最近账单列表
- 预算提醒

### 账单管理 (bills)
- 账单列表展示
- 筛选和搜索
- 分组显示
- 批量操作

### 统计分析 (statistics)
- 饼图显示分类统计
- 折线图显示趋势
- 月度/年度切换
- 预算执行情况

### 家庭管理 (family)
- 家庭信息展示
- 成员管理
- 邀请码生成
- 家庭切换

## 开发指南

### 添加新页面

1. 在 `pages` 目录下创建新页面文件夹
2. 创建页面文件：`.wxml`, `.wxss`, `.js`, `.json`
3. 在 `app.json` 中注册页面路径

### 网络请求

使用封装的请求方法：

```javascript
const app = getApp();

// GET请求
const data = await app.request({
  url: '/bills',
  method: 'GET'
});

// POST请求
await app.request({
  url: '/bills',
  method: 'POST',
  data: { amount: 100, description: '午餐' }
});
```

### 全局数据管理

```javascript
const app = getApp();

// 获取全局数据
const userInfo = app.globalData.userInfo;

// 设置全局数据
app.globalData.currentFamily = familyData;
```

## 部署说明

### 开发环境
1. 使用微信开发者工具进行开发和调试
2. 配置开发环境的API地址

### 生产环境
1. 修改API地址为生产环境
2. 在微信公众平台配置服务器域名
3. 上传代码并提交审核
4. 发布小程序

## 注意事项

1. **域名配置**: 确保API域名已在微信公众平台配置
2. **HTTPS要求**: 生产环境必须使用HTTPS
3. **图片资源**: 建议使用CDN存储图片资源
4. **性能优化**: 注意小程序包大小限制(2MB)
5. **用户体验**: 适配不同屏幕尺寸

## 常见问题

### Q: 登录失败怎么办？
A: 检查微信小程序配置和后端API是否正常，确认AppID和AppSecret配置正确。

### Q: 网络请求失败？
A: 检查API地址配置，确认域名已在微信公众平台配置，生产环境需要HTTPS。

### Q: 图片显示不出来？
A: 检查图片路径是否正确，确认图片资源存在。

## 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 实现基础账单管理功能
- 支持家庭多用户协作
- 提供统计分析功能

## 许可证

MIT License

## 联系方式

如有问题或建议，请联系开发团队。
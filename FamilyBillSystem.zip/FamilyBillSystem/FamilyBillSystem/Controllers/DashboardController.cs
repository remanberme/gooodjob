using FamilyBillSystem.Data;
using FamilyBillSystem.DTOs;
using FamilyBillSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FamilyBillSystem.Controllers
{
    [Route("api/dashboard")]
    [ApiController]
    [Authorize]
    public class DashboardController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<DashboardController> _logger;

        public DashboardController(AppDbContext context, ILogger<DashboardController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/dashboard/overview
        [HttpGet("overview")]
        public async Task<IActionResult> GetDashboardOverview()
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var now = DateTime.Now;
                var year = now.Year;
                var month = now.Month;

                // 获取用户所属的家庭
                var userFamilyIds = await _context.FamilyMembers
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => fm.FamilyId)
                    .ToListAsync();

                if (!userFamilyIds.Any())
                {
                    return Ok(ServiceResponse.CreateSuccess(new
                    {
                        monthlyStats = new
                        {
                            totalIncome = 0m,
                            totalExpense = 0m,
                            balance = 0m
                        },
                        recentBills = new List<object>(),
                        budgetAlerts = new List<object>()
                    }));
                }

                // 获取月度统计
                var monthlyStats = await GetMonthlyStatistics(userFamilyIds, year, month);

                // 获取最近账单
                var recentBills = await GetRecentBills(userFamilyIds, 5);

                // 获取预算提醒
                var budgetAlerts = await GetBudgetAlerts(userFamilyIds, year, month);

                return Ok(ServiceResponse.CreateSuccess(new
                {
                    monthlyStats,
                    recentBills,
                    budgetAlerts
                }));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取首页概览数据失败");
                return StatusCode(500, ServiceResponse.Error("获取首页数据失败"));
            }
        }

        private async Task<object> GetMonthlyStatistics(List<int> userFamilyIds, int year, int month)
        {
            var startDate = new DateTime(year, month, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);

            var bills = await _context.Bills
                .Where(b => userFamilyIds.Contains(b.FamilyId) &&
                           b.BillDate >= startDate &&
                           b.BillDate <= endDate &&
                           b.DeletedAt == null &&
                           b.Status == "confirmed")
                .ToListAsync();

            var totalIncome = bills.Where(b => b.Type == "income").Sum(b => b.Amount);
            var totalExpense = bills.Where(b => b.Type == "expense").Sum(b => b.Amount);
            var balance = totalIncome - totalExpense;

            return new
            {
                totalIncome,
                totalExpense,
                balance,
                billCount = bills.Count
            };
        }

        private async Task<List<object>> GetRecentBills(List<int> userFamilyIds, int count)
        {
            var bills = await _context.Bills
                .Include(b => b.Category)
                .Include(b => b.User)
                .Where(b => userFamilyIds.Contains(b.FamilyId) &&
                           b.DeletedAt == null)
                .OrderByDescending(b => b.BillDate)
                .ThenByDescending(b => b.CreatedAt)
                .Take(count)
                .Select(b => new
                {
                    id = b.Id,
                    amount = b.Amount,
                    description = b.Description,
                    billDate = b.BillDate,
                    categoryId = b.CategoryId,
                    categoryName = b.Category != null ? b.Category.Name : "未分类",
                    categoryIcon = b.Category != null ? b.Category.Icon : "default",
                    categoryColor = b.Category != null ? b.Category.Color : "#666666",
                    categoryType = b.Type == "income" ? 1 : 2,
                    userNickName = b.User.Nickname,
                    username = b.User.Email
                })
                .ToListAsync();

            return bills.Cast<object>().ToList();
        }

        private async Task<List<object>> GetBudgetAlerts(List<int> userFamilyIds, int year, int month)
        {
            var startDate = new DateTime(year, month, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);

            // 获取当月支出
            var monthlyExpenses = await _context.Bills
                .Where(b => userFamilyIds.Contains(b.FamilyId) &&
                           b.Type == "expense" &&
                           b.BillDate >= startDate &&
                           b.BillDate <= endDate &&
                           b.DeletedAt == null &&
                           b.Status == "confirmed")
                .GroupBy(b => b.CategoryId)
                .Select(g => new
                {
                    CategoryId = g.Key,
                    Amount = g.Sum(b => b.Amount)
                })
                .ToListAsync();

            // 获取分类信息
            var categories = await _context.Categories
                .Where(c => c.Type == "expense" &&
                           (c.FamilyId == null || userFamilyIds.Contains(c.FamilyId.Value)))
                .ToListAsync();

            var alerts = new List<object>();

            foreach (var category in categories)
            {
                var spent = monthlyExpenses.FirstOrDefault(e => e.CategoryId == category.Id)?.Amount ?? 0m;
                var budget = GetDefaultBudgetForCategory(category.Name); // 模拟预算金额
                
                if (budget > 0)
                {
                    var utilizationRate = (spent / budget) * 100;
                    
                    if (utilizationRate >= 80) // 使用率超过80%的分类
                    {
                        var isOverBudget = spent > budget;
                        alerts.Add(new
                        {
                            id = category.Id,
                            categoryName = category.Name,
                            categoryIcon = category.Icon,
                            categoryColor = category.Color,
                            amount = budget,
                            usedAmount = spent,
                            usagePercentage = Math.Round(utilizationRate, 1),
                            isOverBudget,
                            message = isOverBudget
                                ? $"{category.Name}已超出预算"
                                : $"{category.Name}接近预算上限"
                        });
                    }
                }
            }

            return alerts;
        }

        private decimal GetDefaultBudgetForCategory(string categoryName)
        {
            // 模拟预算数据，实际项目中应该从预算表获取
            return categoryName switch
            {
                "餐饮" => 1000m,
                "交通" => 500m,
                "购物" => 800m,
                "娱乐" => 300m,
                "医疗" => 200m,
                "教育" => 600m,
                "住房" => 2000m,
                "通讯" => 100m,
                _ => 500m
            };
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
            {
                return userId;
            }
            return null;
        }
    }
}
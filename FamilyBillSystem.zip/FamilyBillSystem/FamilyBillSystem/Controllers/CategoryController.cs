﻿using FamilyBillSystem.Data;
using FamilyBillSystem.DTOs;
using FamilyBillSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FamilyBillSystem.Controllers
{
    [Route("api/categories")]
    [ApiController]
    [Authorize]
    public class CategoryController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<CategoryController> _logger;

        public CategoryController(AppDbContext context, ILogger<CategoryController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/category
        [HttpGet]
        public async Task<IActionResult> GetCategories(string? type = null)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                // 获取用户所属的家庭
                var userFamilyIds = await _context.FamilyMembers
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => fm.FamilyId)
                    .ToListAsync();

                var query = _context.Categories
                    .Where(c => c.DeletedAt == null &&
                               (c.FamilyId == null || userFamilyIds.Contains(c.FamilyId.Value)));

                // 按类型筛选
                if (!string.IsNullOrEmpty(type))
                    query = query.Where(c => c.Type == type);

                var categories = await query
                    .OrderBy(c => c.ParentId.HasValue ? 1 : 0) // 父分类在前
                    .ThenBy(c => c.SortOrder)
                    .ThenBy(c => c.Name)
                    .Select(c => new
                    {
                        c.Id,
                        c.Name,
                        c.Type,
                        c.Icon,
                        c.Color,
                        c.ParentId,
                        c.FamilyId,
                        IsSystem = c.FamilyId == null,
                        c.SortOrder
                    })
                    .ToListAsync();

                // 构建层级结构
                var parentCategories = categories.Where(c => c.ParentId == null).ToList();
                var result = parentCategories.Select(parent => new
                {
                    parent.Id,
                    parent.Name,
                    parent.Type,
                    parent.Icon,
                    parent.Color,
                    parent.ParentId,
                    parent.FamilyId,
                    parent.IsSystem,
                    parent.SortOrder,
                    Children = categories.Where(c => c.ParentId == parent.Id).ToList()
                }).ToList();

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取分类列表失败");
                return StatusCode(500, new { message = "获取分类列表失败" });
            }
        }

        // POST: api/category
        [HttpPost]
        public async Task<IActionResult> CreateCategory([FromBody] CreateCategoryRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                // 验证用户是否属于指定家庭
                if (request.FamilyId.HasValue)
                {
                    var isFamilyMember = await _context.FamilyMembers
                        .AnyAsync(fm => fm.UserId == userId && fm.FamilyId == request.FamilyId && fm.Status == "active");

                    if (!isFamilyMember)
                        return Forbid("您不是该家庭的成员");
                }

                var category = new Category
                {
                    Name = request.Name,
                    Type = request.Type,
                    Icon = request.Icon ?? "default",
                    Color = request.Color ?? "#666666",
                    ParentId = request.ParentId,
                    FamilyId = request.FamilyId,
                    SortOrder = request.SortOrder ?? 0,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Categories.Add(category);
                await _context.SaveChangesAsync();

                return Ok(new { message = "分类创建成功", categoryId = category.Id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "创建分类失败");
                return StatusCode(500, new { message = "创建分类失败" });
            }
        }

        // PUT: api/category/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] UpdateCategoryRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var category = await _context.Categories.FindAsync(id);
                if (category == null || category.DeletedAt != null)
                    return NotFound("分类不存在");

                // 系统分类不能修改
                if (category.FamilyId == null)
                    return Forbid("系统分类不能修改");

                // 验证权限
                var isFamilyMember = await _context.FamilyMembers
                    .AnyAsync(fm => fm.UserId == userId && fm.FamilyId == category.FamilyId && fm.Status == "active");

                if (!isFamilyMember)
                    return Forbid("您没有权限修改此分类");

                // 更新分类信息
                if (!string.IsNullOrEmpty(request.Name))
                    category.Name = request.Name;
                if (!string.IsNullOrEmpty(request.Icon))
                    category.Icon = request.Icon;
                if (!string.IsNullOrEmpty(request.Color))
                    category.Color = request.Color;
                if (request.SortOrder.HasValue)
                    category.SortOrder = request.SortOrder.Value;

                category.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();

                return Ok(new { message = "分类更新成功" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "更新分类失败");
                return StatusCode(500, new { message = "更新分类失败" });
            }
        }

        // DELETE: api/category/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var category = await _context.Categories.FindAsync(id);
                if (category == null || category.DeletedAt != null)
                    return NotFound("分类不存在");

                // 系统分类不能删除
                if (category.FamilyId == null)
                    return Forbid("系统分类不能删除");

                // 验证权限
                var isFamilyMember = await _context.FamilyMembers
                    .AnyAsync(fm => fm.UserId == userId && fm.FamilyId == category.FamilyId && fm.Status == "active");

                if (!isFamilyMember)
                    return Forbid("您没有权限删除此分类");

                // 检查是否有账单使用此分类
                var hasBills = await _context.Bills
                    .AnyAsync(b => b.CategoryId == id && b.DeletedAt == null);

                if (hasBills)
                    return BadRequest("该分类下还有账单记录，无法删除");

                // 软删除
                category.DeletedAt = DateTime.Now;
                category.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();

                return Ok(new { message = "分类删除成功" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "删除分类失败");
                return StatusCode(500, new { message = "删除分类失败" });
            }
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId) ? userId : null;
        }
    }

    // DTO类
    public class CreateCategoryRequest
    {
        public string Name { get; set; } = "";
        public string Type { get; set; } = ""; // income | expense
        public string? Icon { get; set; }
        public string? Color { get; set; }
        public int? ParentId { get; set; }
        public int? FamilyId { get; set; }
        public int? SortOrder { get; set; }
    }

    public class UpdateCategoryRequest
    {
        public string? Name { get; set; }
        public string? Icon { get; set; }
        public string? Color { get; set; }
        public int? SortOrder { get; set; }
    }
}
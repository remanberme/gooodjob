// pages/index/index.js
const app = getApp();

Page({
  data: {
    userInfo: {},
    currentFamily: null,
    greeting: '',
    currentMonth: '',
    monthlyStats: {
      income: '0.00',
      expense: '0.00',
      balance: '0.00'
    },
    recentBills: [],
    budgetAlerts: [],
    showAddOptions: false
  },

  onLoad() {
    this.checkLoginStatus();
  },

  onShow() {
    if (app.globalData.token) {
      this.initPageData();
      this.loadData();
    }
  },

  // 检查登录状态
  checkLoginStatus() {
    if (!app.globalData.token) {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }
  },

  // 初始化页面数据
  initPageData() {
    const userInfo = app.globalData.userInfo || {};
    const currentFamily = wx.getStorageSync('currentFamily');
    
    // 设置问候语
    const hour = new Date().getHours();
    let greeting = '早上好';
    if (hour >= 12 && hour < 18) {
      greeting = '下午好';
    } else if (hour >= 18) {
      greeting = '晚上好';
    }

    // 设置当前月份
    const now = new Date();
    const currentMonth = `${now.getFullYear()}年${now.getMonth() + 1}月`;

    this.setData({
      userInfo,
      currentFamily,
      greeting,
      currentMonth
    });
  },

  // 加载数据
  async loadData() {
    try {
      await Promise.all([
        this.loadMonthlyStats(),
        this.loadRecentBills(),
        this.loadBudgetAlerts()
      ]);
    } catch (error) {
      console.error('加载数据失败:', error);
    }
  },

  // 加载月度统计
  async loadMonthlyStats() {
    try {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;

      const res = await app.request({
        url: `/bills/statistics/monthly?year=${year}&month=${month}`
      });

      this.setData({
        monthlyStats: {
          income: app.formatAmount(res.income || 0),
          expense: app.formatAmount(res.expense || 0),
          balance: app.formatAmount((res.income || 0) - (res.expense || 0))
        }
      });
    } catch (error) {
      console.error('加载月度统计失败:', error);
    }
  },

  // 加载最近账单
  async loadRecentBills() {
    try {
      const res = await app.request({
        url: '/bills?page=1&pageSize=5&sortBy=BillDate&sortDescending=true'
      });

      const bills = (res.data || []).map(bill => ({
        ...bill,
        billDate: app.formatDate(bill.billDate, 'MM-DD'),
        amount: app.formatAmount(bill.amount)
      }));

      this.setData({
        recentBills: bills
      });
    } catch (error) {
      console.error('加载最近账单失败:', error);
    }
  },

  // 加载预算提醒
  async loadBudgetAlerts() {
    try {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;

      const res = await app.request({
        url: `/budgets/summary?year=${year}&month=${month}`
      });

      // 筛选出需要提醒的预算（使用率超过80%或已超出）
      const alerts = (res.budgets || []).filter(budget => 
        budget.usagePercentage >= 80
      ).map(budget => ({
        ...budget,
        usedAmount: app.formatAmount(budget.usedAmount),
        amount: app.formatAmount(budget.amount)
      }));

      this.setData({
        budgetAlerts: alerts
      });
    } catch (error) {
      console.error('加载预算提醒失败:', error);
    }
  },

  // 快速添加支出
  quickAddExpense() {
    this.hideAddOptions();
    wx.navigateTo({
      url: '/pages/add-bill/add-bill?type=expense'
    });
  },

  // 快速添加收入
  quickAddIncome() {
    this.hideAddOptions();
    wx.navigateTo({
      url: '/pages/add-bill/add-bill?type=income'
    });
  },

  // 跳转到账单页面
  goToBills() {
    wx.switchTab({
      url: '/pages/bills/bills'
    });
  },

  // 跳转到统计页面
  goToStatistics() {
    wx.switchTab({
      url: '/pages/statistics/statistics'
    });
  },

  // 跳转到家庭页面
  goToFamily() {
    wx.switchTab({
      url: '/pages/family/family'
    });
  },

  // 查看账单详情
  viewBillDetail(e) {
    const bill = e.currentTarget.dataset.bill;
    wx.navigateTo({
      url: `/pages/bill-detail/bill-detail?id=${bill.id}`
    });
  },

  // 显示添加选项
  showAddOptions() {
    this.setData({
      showAddOptions: true
    });
  },

  // 隐藏添加选项
  hideAddOptions() {
    this.setData({
      showAddOptions: false
    });
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadData().finally(() => {
      wx.stopPullDownRefresh();
    });
  },
  
  // 头像加载失败处理
  onAvatarLoadError() {
    console.log('头像加载失败，使用默认头像');
    this.setData({
      'userInfo.avatar': '/images/user.png'
    });
  }
});
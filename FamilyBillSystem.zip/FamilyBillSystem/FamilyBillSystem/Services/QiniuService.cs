using FamilyBillSystem.Utils;
using Microsoft.Extensions.Options;
using Qiniu.Http;
using Qiniu.Storage;
using Qiniu.Util;

namespace FamilyBillSystem.Services
{
    public class QiniuService
    {
        private readonly QiniuSettings _settings;
        private readonly ILogger<QiniuService> _logger;
        private readonly Mac _mac;

        public QiniuService(IOptions<QiniuSettings> settings, ILogger<QiniuService> logger)
        {
            _settings = settings.Value;
            _logger = logger;
            _mac = new Mac(_settings.AccessKey, _settings.SecretKey);
        }

        /// <summary>
        /// 上传文件到七牛云
        /// </summary>
        /// <param name="fileStream">文件流</param>
        /// <param name="fileName">文件名（包含路径，如：avatars/user_123.jpg）</param>
        /// <returns>文件的完整访问URL</returns>
        public async Task<string> UploadFileAsync(Stream fileStream, string fileName)
        {
            try
            {
                _logger.LogInformation($"开始上传文件到七牛云: {fileName}");

                // 生成上传凭证
                var putPolicy = new PutPolicy
                {
                    Scope = $"{_settings.Bucket}:{fileName}",
                    DeleteAfterDays = 0  // 0表示永久保存
                };
                var uploadToken = Auth.CreateUploadToken(_mac, putPolicy.ToJsonString());

                // 配置上传参数
                var config = new Config
                {
                    Zone = Zone.ZONE_CN_East,  // 华东区域，根据你的bucket所在区域调整
                    UseHttps = true,
                    UseCdnDomains = true,
                    ChunkSize = ChunkUnit.U512K
                };

                // 创建表单上传对象
                var formUploader = new FormUploader(config);

                // 将Stream转换为byte[]
                using var memoryStream = new MemoryStream();
                await fileStream.CopyToAsync(memoryStream);
                var fileBytes = memoryStream.ToArray();

                // 上传文件
                var result = formUploader.UploadData(fileBytes, fileName, uploadToken, null);

                if (result.Code == 200)
                {
                    var fileUrl = $"{_settings.Domain.TrimEnd('/')}/{fileName}";
                    _logger.LogInformation($"文件上传成功: {fileUrl}");
                    return fileUrl;
                }
                else
                {
                    _logger.LogError($"七牛云上传失败: Code={result.Code}, Error={result.Text}");
                    throw new Exception($"上传失败: {result.Text}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"上传文件到七牛云时发生异常: {fileName}");
                throw;
            }
        }

        /// <summary>
        /// 删除七牛云上的文件
        /// </summary>
        /// <param name="fileName">文件名</param>
        public async Task<bool> DeleteFileAsync(string fileName)
        {
            try
            {
                _logger.LogInformation($"开始删除七牛云文件: {fileName}");

                var config = new Config
                {
                    Zone = Zone.ZONE_CN_East,
                    UseHttps = true
                };

                var bucketManager = new BucketManager(_mac, config);
                var result = bucketManager.Delete(_settings.Bucket, fileName);

                if (result.Code == 200)
                {
                    _logger.LogInformation($"文件删除成功: {fileName}");
                    return true;
                }
                else
                {
                    _logger.LogWarning($"文件删除失败: Code={result.Code}, Error={result.Text}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"删除七牛云文件时发生异常: {fileName}");
                return false;
            }
        }

        /// <summary>
        /// 从URL中提取文件名
        /// </summary>
        public string ExtractFileNameFromUrl(string url)
        {
            if (string.IsNullOrEmpty(url) || !url.Contains(_settings.Domain))
                return string.Empty;

            var uri = new Uri(url);
            return uri.AbsolutePath.TrimStart('/');
        }
    }
}

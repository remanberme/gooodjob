using FamilyBillSystem.Data;
using FamilyBillSystem.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Http.Features;

namespace FamilyBillSystem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // ---------------- 日志配置 ----------------
            builder.Logging.ClearProviders();
            builder.Logging.AddConsole();
            builder.Logging.AddDebug();

            // ---------------- MySQL 配置 ----------------
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
            builder.Services.AddDbContext<AppDbContext>(options =>
                options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString),
                    mysqlOptions =>
                    {
                        mysqlOptions.EnableRetryOnFailure(
                            maxRetryCount: 5,
                            maxRetryDelay: TimeSpan.FromSeconds(30),
                            errorNumbersToAdd: null
                        );
                    })
                .EnableSensitiveDataLogging()
                .LogTo(Console.WriteLine, LogLevel.Information)
            );

            // ---------------- JWT 配置 ----------------
            var key = Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]);
            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(1),
                    ValidIssuer = builder.Configuration["Jwt:Issuer"],
                    ValidAudience = builder.Configuration["Jwt:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(key)
                };
            });
            builder.Services.AddAuthorization();

            // ---------------- 邮件服务 ----------------
            builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("Email"));
            builder.Services.AddSingleton<EmailService>();

            // ---------------- AuthService ----------------
            builder.Services.AddScoped<AuthService>();
            builder.Services.AddHttpClient<AuthService>();

            // ---------------- CORS ----------------
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            // ---------------- Controllers & Swagger ----------------
            builder.Services.AddControllers();
            builder.Services.Configure<IISServerOptions>(options =>
            {
                options.MaxRequestBodySize = 10 * 1024 * 1024; // 10MB
            });
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // ---------------- HTTP 管道 ----------------
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseCors("AllowAll");

            // 🔹 启用认证与授权
            app.UseAuthentication();
            app.UseAuthorization();

            // ---------------- 调试上传头像 ----------------
            app.Use(async (context, next) =>
            {
                if (context.Request.Path.StartsWithSegments("/api/auth/upload-avatar"))
                {
                    var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();

                    // 打印请求头
                    logger.LogInformation("收到头像上传请求");
                    logger.LogInformation("请求路径: {Path}", context.Request.Path);
                    logger.LogInformation("Authorization头: {AuthHeader}", context.Request.Headers["Authorization"]);

                    // 打印认证状态
                    logger.LogInformation("User.Identity.IsAuthenticated={IsAuthenticated}", context.User.Identity?.IsAuthenticated);
                    if (context.User.Identity?.IsAuthenticated == true)
                    {
                        logger.LogInformation("User.Claims={Claims}",
                            string.Join(", ", context.User.Claims.Select(c => $"{c.Type}:{c.Value}")));
                    }
                }

                await next();
            });

            app.MapControllers();

            app.Run();
        }
    }
}

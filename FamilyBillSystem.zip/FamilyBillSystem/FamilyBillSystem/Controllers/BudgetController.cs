﻿using FamilyBillSystem.Data;
using FamilyBillSystem.DTOs;
using FamilyBillSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FamilyBillSystem.Controllers
{
    [Route("api/budgets")]
    [ApiController]
    [Authorize]
    public class BudgetController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<BudgetController> _logger;

        public BudgetController(AppDbContext context, ILogger<BudgetController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/budget/summary
        [HttpGet("summary")]
        public async Task<IActionResult> GetBudgetSummary(int year, int month)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                // 获取用户所属的家庭
                var userFamilyIds = await _context.FamilyMembers
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => fm.FamilyId)
                    .ToListAsync();

                if (!userFamilyIds.Any())
                {
                    return Ok(new
                    {
                        year,
                        month,
                        totalBudget = 0m,
                        totalSpent = 0m,
                        remaining = 0m,
                        utilizationRate = 0m,
                        categoryBudgets = new List<object>(),
                        alerts = new List<object>()
                    });
                }

                var startDate = new DateTime(year, month, 1);
                var endDate = startDate.AddMonths(1).AddDays(-1);

                // 获取当月支出
                var monthlyExpenses = await _context.Bills
                    .Where(b => userFamilyIds.Contains(b.FamilyId) &&
                               b.Type == "expense" &&
                               b.BillDate >= startDate &&
                               b.BillDate <= endDate &&
                               b.DeletedAt == null &&
                               b.Status == "confirmed")
                    .GroupBy(b => b.CategoryId)
                    .Select(g => new
                    {
                        CategoryId = g.Key,
                        Amount = g.Sum(b => b.Amount)
                    })
                    .ToListAsync();

                var totalSpent = monthlyExpenses.Sum(e => e.Amount);

                // 模拟预算数据（实际项目中应该有预算表）
                var categories = await _context.Categories
                    .Where(c => c.Type == "expense" &&
                               (c.FamilyId == null || userFamilyIds.Contains(c.FamilyId.Value)))
                    .ToListAsync();

                var categoryBudgets = categories.Select(c =>
                {
                    var spent = monthlyExpenses.FirstOrDefault(e => e.CategoryId == c.Id)?.Amount ?? 0m;
                    var budget = GetDefaultBudgetForCategory(c.Name); // 模拟预算金额
                    var utilizationRate = budget > 0 ? (spent / budget) * 100 : 0;

                    return new
                    {
                        categoryId = c.Id,
                        categoryName = c.Name,
                        categoryIcon = c.Icon,
                        categoryColor = c.Color,
                        budget,
                        spent,
                        remaining = Math.Max(0, budget - spent),
                        utilizationRate = Math.Round(utilizationRate, 2),
                        isOverBudget = spent > budget
                    };
                }).ToList();

                var totalBudget = categoryBudgets.Sum(cb => cb.budget);
                var remaining = Math.Max(0, totalBudget - totalSpent);
                var overallUtilizationRate = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

                // 生成预算提醒
                var alerts = categoryBudgets
                    .Where(cb => cb.utilizationRate >= 80) // 使用率超过80%的分类
                    .Select(cb => new
                    {
                        type = cb.isOverBudget ? "over_budget" : "budget_warning",
                        categoryName = cb.categoryName,
                        message = cb.isOverBudget
                            ? $"{cb.categoryName}已超出预算 ¥{cb.spent - cb.budget:F2}"
                            : $"{cb.categoryName}预算使用率已达{cb.utilizationRate:F1}%",
                        severity = cb.isOverBudget ? "high" : "medium"
                    })
                    .ToList();

                return Ok(new
                {
                    year,
                    month,
                    totalBudget,
                    totalSpent,
                    remaining,
                    utilizationRate = Math.Round(overallUtilizationRate, 2),
                    categoryBudgets,
                    alerts
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取预算汇总失败");
                return StatusCode(500, new { message = "获取预算汇总失败" });
            }
        }

        // GET: api/budget/categories
        [HttpGet("categories")]
        public async Task<IActionResult> GetCategoryBudgets(int year, int month)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var userFamilyIds = await _context.FamilyMembers
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => fm.FamilyId)
                    .ToListAsync();

                var startDate = new DateTime(year, month, 1);
                var endDate = startDate.AddMonths(1).AddDays(-1);

                // 获取支出分类和实际支出
                var expenseCategories = await _context.Categories
                    .Where(c => c.Type == "expense" &&
                               (c.FamilyId == null || userFamilyIds.Contains(c.FamilyId.Value)))
                    .ToListAsync();

                var actualExpenses = await _context.Bills
                    .Where(b => userFamilyIds.Contains(b.FamilyId) &&
                               b.Type == "expense" &&
                               b.BillDate >= startDate &&
                               b.BillDate <= endDate &&
                               b.DeletedAt == null &&
                               b.Status == "confirmed")
                    .GroupBy(b => b.CategoryId)
                    .Select(g => new
                    {
                        CategoryId = g.Key,
                        Amount = g.Sum(b => b.Amount)
                    })
                    .ToDictionaryAsync(x => x.CategoryId, x => x.Amount);

                var categoryBudgets = expenseCategories.Select(c =>
                {
                    var actualAmount = actualExpenses.GetValueOrDefault(c.Id, 0m);
                    var budgetAmount = GetDefaultBudgetForCategory(c.Name);

                    return new
                    {
                        categoryId = c.Id,
                        categoryName = c.Name,
                        categoryIcon = c.Icon,
                        categoryColor = c.Color,
                        budgetAmount,
                        actualAmount,
                        remainingAmount = Math.Max(0, budgetAmount - actualAmount),
                        utilizationRate = budgetAmount > 0 ? Math.Round((actualAmount / budgetAmount) * 100, 2) : 0,
                        isOverBudget = actualAmount > budgetAmount
                    };
                }).OrderByDescending(x => x.utilizationRate).ToList();

                return Ok(categoryBudgets);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取分类预算失败");
                return StatusCode(500, new { message = "获取分类预算失败" });
            }
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId) ? userId : null;
        }

        // 模拟预算金额的方法（实际项目中应该从预算表获取）
        private decimal GetDefaultBudgetForCategory(string categoryName)
        {
            return categoryName.ToLower() switch
            {
                "餐饮" or "食物" or "外卖" => 1500m,
                "交通" or "出行" => 800m,
                "购物" or "服装" => 1000m,
                "娱乐" or "休闲" => 600m,
                "医疗" or "健康" => 500m,
                "教育" or "学习" => 800m,
                "住房" or "房租" => 3000m,
                "水电费" or "生活费" => 400m,
                "通讯" or "话费" => 200m,
                "其他" => 500m,
                _ => 300m
            };
        }
    }
}
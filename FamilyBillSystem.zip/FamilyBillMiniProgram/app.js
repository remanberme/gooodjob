// app.js
App({
  globalData: {
    userInfo: null,
    token: null,
    baseUrl: 'https://anymore-courses-graham-deleted.trycloudflare.com/api',
    currentFamily: null,
    categories: [],
    systemInfo: null,
    isRefreshingToken: false, // 避免重复刷新
    requestQueue: []          // token 刷新期间的请求队列
  },

  onLaunch() {
    wx.getSystemInfo({
      success: (res) => {
        this.globalData.systemInfo = res;
      }
    });
    this.checkLoginStatus();
  },

  checkLoginStatus() {
    const token = wx.getStorageSync('token');
    const userInfo = wx.getStorageSync('userInfo');

    if (token && userInfo) {
      this.globalData.token = token;
      this.globalData.userInfo = userInfo;
      this.validateToken(token).catch(() => this.logout());
    }
  },

  async validateToken(token) {
    if (!token) {
      console.log('未找到token，需要重新登录');
      this.logout();
      return;
    }
    
    try {
      const res = await this.request({
        url: '/auth/validate-token',
        method: 'POST',
        data: { token },
        noAutoRefresh: true  // 防止循环调用
      });
      
      if (!res || !res.isValid) {
        console.log('Token验证失败:', res);
        this.logout();
      }
    } catch (err) {
      console.error('Token验证错误:', err);
      // 只在验证失败时登出，网络错误不登出
      if (err.statusCode === 401) {
        this.logout();
      }
    }
  },

  async login(loginData) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: `${this.globalData.baseUrl}/auth/wechat-login`,
        method: 'POST',
        data: loginData,
        header: { 'Content-Type': 'application/json' },
        success: (res) => {
          if (res.statusCode === 200 && res.data.token && res.data.user) {
            const { token, user } = res.data;
            this.globalData.token = token;
            this.globalData.userInfo = user;
            wx.setStorageSync('token', token);
            wx.setStorageSync('userInfo', user);
            resolve(res.data);
          } else {
            reject(res.data || { message: '登录失败' });
          }
        },
        fail: (err) => reject(err)
      });
    });
  },

  logout() {
    this.globalData.token = null;
    this.globalData.userInfo = null;
    this.globalData.currentFamily = null;
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
    wx.removeStorageSync('currentFamily');
    wx.reLaunch({ url: '/pages/login/login' });
  },

  async request(options) {
    return new Promise((resolve, reject) => {
      const doRequest = () => {
        console.log(`发起请求: ${options.method || 'GET'} ${options.url}`);
        wx.request({
          url: `${this.globalData.baseUrl}${options.url}`,
          method: options.method || 'GET',
          data: options.data || {},
          header: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.globalData.token || ''}`,
            ...options.header
          },
          success: async (res) => {
            console.log(`请求成功: ${options.url}`, res.statusCode, res.data);
            if (res.statusCode === 200) return resolve(res.data);

            // token过期或未登录
            if ((res.statusCode === 401 || (res.data && res.data.code === 'TokenExpired')) && !options.noAutoRefresh) {
              console.log('Token已过期，尝试刷新...');
              this.handleTokenRefresh().then(() => {
                console.log('Token刷新成功，重试请求');
                doRequest();
              }).catch((err) => {
                console.error('Token刷新失败:', err);
                this.logout();
                reject({ message: '登录已过期，请重新登录' });
              });
            } else {
              const error = res.data || { message: '请求失败' };
              console.error('请求失败:', error);
              reject(error);
            }
          },
          fail: (err) => {
            console.error('请求错误:', err);
            reject({ 
              message: '网络错误，请检查网络连接',
              error: err
            });
          }
        });
      };

      if (this.globalData.isRefreshingToken) {
        console.log('Token刷新中，加入请求队列');
        this.globalData.requestQueue.push(() => doRequest());
      } else {
        doRequest();
      }
    });
  },

  async handleTokenRefresh() {
    if (this.globalData.isRefreshingToken) {
      console.log('Token刷新中，等待...');
      return new Promise(resolve => {
        const interval = setInterval(() => {
          if (!this.globalData.isRefreshingToken) {
            clearInterval(interval);
            resolve();
          }
        }, 100);
      });
    }

    this.globalData.isRefreshingToken = true;
    console.log('开始刷新Token...');
    
    try {
      const userInfo = this.globalData.userInfo;
      if (!userInfo || !userInfo.openId) {
        throw new Error('用户信息不完整，无法刷新Token');
      }

      // 使用refresh token或重新登录
      const res = await this.login({ openId: userInfo.openId });
      if (!res || !res.token) {
        throw new Error('刷新Token失败');
      }

      console.log('Token刷新成功');
      this.globalData.token = res.token;
      wx.setStorageSync('token', res.token);

      // 执行队列中的请求
      const queue = this.globalData.requestQueue;
      this.globalData.requestQueue = [];
      console.log(`执行${queue.length}个等待中的请求`);
      queue.forEach(fn => fn());
      
      return res.token;
    } catch (err) {
      console.error('刷新Token失败:', err);
      // 清空请求队列
      this.globalData.requestQueue = [];
      throw err;
    } finally {
      this.globalData.isRefreshingToken = false;
    }
  },

  // UI 辅助函数
  showLoading(title = '加载中...') { wx.showLoading({ title, mask: true }); },
  hideLoading() { wx.hideLoading(); },
  showToast(title, icon = 'none', duration = 2000) { wx.showToast({ title, icon, duration }); },
  showModal(title, content) {
    return new Promise((resolve) => wx.showModal({ title, content, success: res => resolve(res.confirm) }));
  },

  // 工具函数
  formatDate(date, format = 'YYYY-MM-DD') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hour = String(d.getHours()).padStart(2, '0');
    const minute = String(d.getMinutes()).padStart(2, '0');
    const second = String(d.getSeconds()).padStart(2, '0');
    return format.replace('YYYY', year).replace('MM', month).replace('DD', day)
                 .replace('HH', hour).replace('mm', minute).replace('ss', second);
  },

  formatAmount(amount) { return parseFloat(amount).toFixed(2); },
  
  // 日志工具
  log: {
    debug: function(...args) {
      if (__wxConfig && __wxConfig.debug) {
        console.debug('[DEBUG]', ...args);
      }
    },
    info: function(...args) {
      console.log('[INFO]', ...args);
    },
    error: function(...args) {
      console.error('[ERROR]', ...args);
      // 可以在这里添加错误上报逻辑
    }
  }
});

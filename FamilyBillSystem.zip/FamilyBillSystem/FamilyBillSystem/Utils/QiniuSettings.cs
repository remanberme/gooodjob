namespace FamilyBillSystem.Utils
{
    public class QiniuSettings
    {
        public string AccessKey { get; set; } = string.Empty;
        public string SecretKey { get; set; } = string.Empty;
        public string Bucket { get; set; } = string.Empty;
        public string Domain { get; set; } = string.Empty;
    }
}

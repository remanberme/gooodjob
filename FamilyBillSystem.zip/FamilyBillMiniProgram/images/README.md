# 图片资源说明

这个目录用于存放微信小程序的图片资源。

## 需要的图片文件

1. `default-avatar.png` - 默认头像图片 (建议尺寸: 200x200px)
2. `logo.png` - 应用Logo (建议尺寸: 200x200px)
3. `empty-bill.png` - 空账单状态图片 (建议尺寸: 300x200px)
4. `empty-family.png` - 空家庭状态图片 (建议尺寸: 300x200px)

## 图片格式要求

- 支持格式：PNG、JPG、JPEG、GIF
- 建议使用PNG格式以获得更好的透明度支持
- 图片大小建议控制在100KB以内

## 使用方式

在WXML文件中使用相对路径引用：
```xml
<image src="/images/default-avatar.png" mode="aspectFill"></image>
```

## 注意事项

- 微信小程序对图片资源有大小限制，单个包不能超过2MB
- 建议对图片进行适当压缩以减小包体积
- 可以考虑使用网络图片或云存储来减小本地包大小
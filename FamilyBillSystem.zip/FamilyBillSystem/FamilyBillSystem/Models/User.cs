using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FamilyBillSystem.Models
{
    public class User  //用户表
    {
        public int Id { get; set; }


        [MaxLength(64)]
        [Column(TypeName = "varchar(64)")]
        public string? OpenId { get; set; }  //微信登录标识

        [MaxLength(50)]
        [Column(TypeName = "varchar(50)")]
        public string Nickname { get; set; }  //昵称

        [NotMapped]//不保存到数据库
        public string Password { get; set; }

        [Required]
        [ValidateNever]//不验证该属性
        public byte[] PasswordHash { get; set; } = Array.Empty<byte>();

        [Required]
        [ValidateNever]
        public byte[] PasswordSalt { get; set; } = Array.Empty<byte>();

        [MaxLength(255)]
        [Column(TypeName = "varchar(255)")]
        public string AvatarUrl { get; set; }  //头像链接（保留字段，用于兼容性）

        [Column(TypeName = "longblob")]
        [JsonIgnore]  // 不序列化到JSON响应中
        public byte[]? AvatarData { get; set; }  // 头像二进制数据

        [MaxLength(50)]
        [Column(TypeName = "varchar(50)")]
        public string? AvatarContentType { get; set; }  // 头像文件类型，如"image/jpeg"

        [MaxLength(11)]
        [Column(TypeName = "varchar(11)")]
        public string Phone { get; set; }  //手机号

        [MaxLength(100)]
        [Column(TypeName = "varchar(100)")]
        public string? Email { get; set; }  //电子邮箱

        [Column(TypeName = "tinyint")]
        public byte? Gender { get; set; } // 0-保密,1-男,2-女，null-未设置

        [Column(TypeName = "timestamp")]
        public DateTime? LastLoginAt { get; set; }  //最后登录时间

        [Column(TypeName = "int")]
        public int LoginCount { get; set; } = 0;  //登录次数

        [Required]
        [Column(TypeName = "enum('active','frozen')")]
        public string Status { get; set; } = "active";  //账户状态，active-活跃，frozen-冻结

        [Column(TypeName = "json")]
        public string Settings { get; set; } = "{}";  //用户偏好设置

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "timestamp")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;  //用户创建时间

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [Column(TypeName = "timestamp")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;  //用户最近一次更新

        [Column(TypeName = "timestamp")]
        public DateTime? DeletedAt { get; set; }  //删除时间

        //导航属性
        [JsonIgnore]
        public virtual ICollection<Family> CreatedFamilies { get; set; } = new List<Family>();
        
        [JsonIgnore]
        public virtual ICollection<FamilyMember> FamilyMembers { get; set; } = new List<FamilyMember>();
        
        [JsonIgnore]
        public virtual ICollection<Bill> Bills { get; set; } = new List<Bill>();
        
        [JsonIgnore]
        public virtual ICollection<Notification> Notifications { get; set; } = new List<Notification>();
        
        [JsonIgnore]
        public virtual ICollection<NotificationTemplate> CreatedTemplates { get; set; } = new List<NotificationTemplate>();

        //处理设置 JSON 的辅助方法
        [NotMapped]
        public JsonDocument SettingsJson
        {
            get => JsonDocument.Parse(string.IsNullOrEmpty(Settings) ? "{}" : Settings);
            set => Settings = value != null ? JsonSerializer.Serialize(value) : "{}";
        }
    }
}

﻿using FamilyBillSystem.Data;
using FamilyBillSystem.DTOs;
using FamilyBillSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FamilyBillSystem.Controllers
{
    [Route("api/bills")]
    [ApiController]
    [Authorize]
    public class BillController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<BillController> _logger;

        public BillController(AppDbContext context, ILogger<BillController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/bill
        [HttpGet]
        public async Task<IActionResult> GetBills(
            int page = 1,
            int pageSize = 10,
            string? type = null,
            int? categoryId = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            string sortBy = "BillDate",
            bool sortDescending = true)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var query = _context.Bills
                    .Include(b => b.Category)
                    .Include(b => b.User)
                    .Where(b => b.DeletedAt == null);

                // 根据用户的家庭成员关系筛选账单
                var userFamilyIds = await _context.FamilyMembers
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => fm.FamilyId)
                    .ToListAsync();

                query = query.Where(b => userFamilyIds.Contains(b.FamilyId));

                // 应用筛选条件
                if (!string.IsNullOrEmpty(type))
                    query = query.Where(b => b.Type == type);

                if (categoryId.HasValue)
                    query = query.Where(b => b.CategoryId == categoryId);

                if (startDate.HasValue)
                    query = query.Where(b => b.BillDate >= startDate.Value);

                if (endDate.HasValue)
                    query = query.Where(b => b.BillDate <= endDate.Value);

                // 排序
                query = sortBy.ToLower() switch
                {
                    "amount" => sortDescending ? query.OrderByDescending(b => b.Amount) : query.OrderBy(b => b.Amount),
                    "createdat" => sortDescending ? query.OrderByDescending(b => b.CreatedAt) : query.OrderBy(b => b.CreatedAt),
                    _ => sortDescending ? query.OrderByDescending(b => b.BillDate) : query.OrderBy(b => b.BillDate)
                };

                var totalCount = await query.CountAsync();
                var bills = await query
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(b => new
                    {
                        b.Id,
                        b.Type,
                        b.Amount,
                        b.Description,
                        b.BillDate,
                        b.PaymentMethod,
                        b.Status,
                        b.CreatedAt,
                        Category = b.Category != null ? new { b.Category.Id, b.Category.Name, b.Category.Icon, b.Category.Color } : null,
                        User = new { b.User.Id, b.User.Nickname, b.User.AvatarUrl }
                    })
                    .ToListAsync();

                return Ok(new
                {
                    data = bills,
                    pagination = new
                    {
                        page,
                        pageSize,
                        totalCount,
                        totalPages = (int)Math.Ceiling((double)totalCount / pageSize)
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取账单列表失败");
                return StatusCode(500, new { message = "获取账单列表失败" });
            }
        }

        // GET: api/bill/statistics/monthly
        [HttpGet("statistics/monthly")]
        public async Task<IActionResult> GetMonthlyStatistics(int year, int month)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                // 获取用户所属的家庭
                var userFamilyIds = await _context.FamilyMembers
                    .Where(fm => fm.UserId == userId && fm.Status == "active")
                    .Select(fm => fm.FamilyId)
                    .ToListAsync();

                var startDate = new DateTime(year, month, 1);
                var endDate = startDate.AddMonths(1).AddDays(-1);

                var bills = await _context.Bills
                    .Where(b => userFamilyIds.Contains(b.FamilyId) &&
                               b.BillDate >= startDate &&
                               b.BillDate <= endDate &&
                               b.DeletedAt == null &&
                               b.Status == "confirmed")
                    .ToListAsync();

                var totalIncome = bills.Where(b => b.Type == "income").Sum(b => b.Amount);
                var totalExpense = bills.Where(b => b.Type == "expense").Sum(b => b.Amount);
                var balance = totalIncome - totalExpense;

                // 按分类统计
                var categoryStats = bills
                    .GroupBy(b => new { b.Type, b.CategoryId })
                    .Select(g => new
                    {
                        Type = g.Key.Type,
                        CategoryId = g.Key.CategoryId,
                        Amount = g.Sum(b => b.Amount),
                        Count = g.Count()
                    })
                    .ToList();

                // 获取分类信息
                var categoryIds = categoryStats.Select(cs => cs.CategoryId).Where(id => id.HasValue).ToList();
                var categories = await _context.Categories
                    .Where(c => categoryIds.Contains(c.Id))
                    .ToDictionaryAsync(c => c.Id, c => new { c.Name, c.Icon, c.Color });

                var categoryStatsWithNames = categoryStats.Select(cs => new
                {
                    cs.Type,
                    cs.CategoryId,
                    CategoryName = cs.CategoryId.HasValue && categories.ContainsKey(cs.CategoryId.Value)
                        ? categories[cs.CategoryId.Value].Name
                        : "未分类",
                    CategoryIcon = cs.CategoryId.HasValue && categories.ContainsKey(cs.CategoryId.Value)
                        ? categories[cs.CategoryId.Value].Icon
                        : "default",
                    CategoryColor = cs.CategoryId.HasValue && categories.ContainsKey(cs.CategoryId.Value)
                        ? categories[cs.CategoryId.Value].Color
                        : "#666666",
                    cs.Amount,
                    cs.Count
                }).ToList();

                return Ok(new
                {
                    year,
                    month,
                    totalIncome,
                    totalExpense,
                    balance,
                    billCount = bills.Count,
                    categoryStats = categoryStatsWithNames
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取月度统计失败");
                return StatusCode(500, new { message = "获取月度统计失败" });
            }
        }

        // POST: api/bill
        [HttpPost]
        public async Task<IActionResult> CreateBill([FromBody] CreateBillRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                // 验证用户是否属于指定家庭
                var isFamilyMember = await _context.FamilyMembers
                    .AnyAsync(fm => fm.UserId == userId && fm.FamilyId == request.FamilyId && fm.Status == "active");

                if (!isFamilyMember)
                    return Forbid("您不是该家庭的成员");

                var bill = new Bill
                {
                    FamilyId = request.FamilyId,
                    UserId = userId.Value,
                    CategoryId = request.CategoryId,
                    Type = request.Type,
                    Amount = request.Amount,
                    Description = request.Description,
                    PaymentMethod = request.PaymentMethod ?? "",
                    BillDate = request.BillDate,
                    Tags = request.Tags ?? "[]",
                    Status = "confirmed",
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Bills.Add(bill);
                await _context.SaveChangesAsync();

                // 更新家庭统计
                await UpdateFamilyStats(request.FamilyId);

                return Ok(new { message = "账单创建成功", billId = bill.Id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "创建账单失败");
                return StatusCode(500, new { message = "创建账单失败" });
            }
        }

        // PUT: api/bill/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBill(int id, [FromBody] UpdateBillRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var bill = await _context.Bills.FindAsync(id);
                if (bill == null || bill.DeletedAt != null)
                    return NotFound("账单不存在");

                // 验证权限
                var isFamilyMember = await _context.FamilyMembers
                    .AnyAsync(fm => fm.UserId == userId && fm.FamilyId == bill.FamilyId && fm.Status == "active");

                if (!isFamilyMember)
                    return Forbid("您没有权限修改此账单");

                // 更新账单信息
                if (request.CategoryId.HasValue)
                    bill.CategoryId = request.CategoryId;
                if (!string.IsNullOrEmpty(request.Description))
                    bill.Description = request.Description;
                if (request.Amount.HasValue)
                    bill.Amount = request.Amount.Value;
                if (!string.IsNullOrEmpty(request.PaymentMethod))
                    bill.PaymentMethod = request.PaymentMethod;
                if (request.BillDate.HasValue)
                    bill.BillDate = request.BillDate.Value;
                if (!string.IsNullOrEmpty(request.Tags))
                    bill.Tags = request.Tags;

                bill.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();

                // 更新家庭统计
                await UpdateFamilyStats(bill.FamilyId);

                return Ok(new { message = "账单更新成功" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "更新账单失败");
                return StatusCode(500, new { message = "更新账单失败" });
            }
        }

        // DELETE: api/bill/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBill(int id)
        {
            try
            {
                var userId = GetCurrentUserId();
                if (userId == null)
                    return Unauthorized();

                var bill = await _context.Bills.FindAsync(id);
                if (bill == null || bill.DeletedAt != null)
                    return NotFound("账单不存在");

                // 验证权限
                var isFamilyMember = await _context.FamilyMembers
                    .AnyAsync(fm => fm.UserId == userId && fm.FamilyId == bill.FamilyId && fm.Status == "active");

                if (!isFamilyMember)
                    return Forbid("您没有权限删除此账单");

                // 软删除
                bill.DeletedAt = DateTime.Now;
                bill.Status = "deleted";
                bill.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();

                // 更新家庭统计
                await UpdateFamilyStats(bill.FamilyId);

                return Ok(new { message = "账单删除成功" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "删除账单失败");
                return StatusCode(500, new { message = "删除账单失败" });
            }
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId) ? userId : null;
        }

        private async Task UpdateFamilyStats(int familyId)
        {
            var bills = await _context.Bills
                .Where(b => b.FamilyId == familyId && b.DeletedAt == null && b.Status == "confirmed")
                .ToListAsync();

            var totalIncome = bills.Where(b => b.Type == "income").Sum(b => b.Amount);
            var totalExpense = bills.Where(b => b.Type == "expense").Sum(b => b.Amount);

            var stats = await _context.FamilyStats.FirstOrDefaultAsync(fs => fs.FamilyId == familyId);
            if (stats == null)
            {
                stats = new FamilyStats
                {
                    FamilyId = familyId,
                    TotalIncome = totalIncome,
                    TotalExpense = totalExpense,
                    LastUpdated = DateTime.Now
                };
                _context.FamilyStats.Add(stats);
            }
            else
            {
                stats.TotalIncome = totalIncome;
                stats.TotalExpense = totalExpense;
                stats.LastUpdated = DateTime.Now;
            }

            await _context.SaveChangesAsync();
        }
    }
}
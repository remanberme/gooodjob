// pages/add-bill/add-bill.js
const app = getApp();

Page({
  data: {
    billType: 'expense', // expense | income
    amount: '',
    selectedCategory: null,
    billDate: '',
    description: '',
    remark: '',
    loading: false,
    amountFocus: true,
    showKeyboard: true,
    
    // 分类相关
    showCategoryModal: false,
    categoryTab: 'system', // system | custom
    categories: [],
    filteredCategories: [],
    
    // 添加分类
    showAddCategoryForm: false,
    newCategory: {
      name: '',
      color: '#4CAF50'
    },
    colorOptions: [
      '#4CAF50', '#2196F3', '#FF9800', '#f44336', 
      '#9C27B0', '#607D8B', '#795548', '#E91E63',
      '#3F51B5', '#009688', '#8BC34A', '#CDDC39',
      '#FFC107', '#FF5722', '#9E9E9E', '#673AB7'
    ]
  },

  onLoad(options) {
    // 设置默认日期为今天
    const today = new Date();
    const billDate = app.formatDate(today, 'YYYY-MM-DD');
    
    // 从参数获取类型
    const billType = options.type || 'expense';
    
    this.setData({
      billDate,
      billType
    });

    this.loadCategories();
  },

  onShow() {
    // 检查登录状态
    if (!app.globalData.token) {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }
  },

  // 加载分类数据
  async loadCategories() {
    try {
      const res = await app.request({
        url: '/categories'
      });

      this.setData({
        categories: res.data || []
      });

      this.filterCategories();
    } catch (error) {
      console.error('加载分类失败:', error);
      app.showToast('加载分类失败');
    }
  },

  // 筛选分类
  filterCategories() {
    const { categories, billType, categoryTab } = this.data;
    const targetType = billType === 'expense' ? 2 : 1; // CategoryType.Expense = 2, CategoryType.Income = 1

    let filtered = categories.filter(cat => cat.type === targetType);
    
    if (categoryTab === 'system') {
      filtered = filtered.filter(cat => cat.isSystem);
    } else {
      filtered = filtered.filter(cat => !cat.isSystem);
    }

    this.setData({
      filteredCategories: filtered
    });
  },

  // 切换收支类型
  switchType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      billType: type,
      selectedCategory: null
    });
    this.filterCategories();
  },

  // 金额输入
  onAmountInput(e) {
    let value = e.detail.value;
    
    // 限制小数点后两位
    if (value.includes('.')) {
      const parts = value.split('.');
      if (parts[1] && parts[1].length > 2) {
        value = parts[0] + '.' + parts[1].substring(0, 2);
      }
    }

    this.setData({
      amount: value
    });
  },

  // 数字键盘输入
  inputNumber(e) {
    const num = e.currentTarget.dataset.num;
    let { amount } = this.data;
    
    // 如果是0.00，清空重新输入
    if (amount === '0.00') {
      amount = '';
    }
    
    this.setData({
      amount: amount + num
    });
  },

  // 输入小数点
  inputDot() {
    let { amount } = this.data;
    
    if (!amount) {
      amount = '0';
    }
    
    if (!amount.includes('.')) {
      this.setData({
        amount: amount + '.'
      });
    }
  },

  // 删除数字
  deleteNumber() {
    let { amount } = this.data;
    
    if (amount.length > 0) {
      this.setData({
        amount: amount.slice(0, -1)
      });
    }
  },

  // 显示分类选择器
  showCategoryPicker() {
    this.setData({
      showCategoryModal: true,
      showKeyboard: false
    });
  },

  // 隐藏分类选择器
  hideCategoryPicker() {
    this.setData({
      showCategoryModal: false,
      showKeyboard: true
    });
  },

  // 切换分类标签
  switchCategoryTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({
      categoryTab: tab
    });
    this.filterCategories();
  },

  // 选择分类
  selectCategory(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({
      selectedCategory: category,
      showCategoryModal: false,
      showKeyboard: true
    });
  },

  // 显示添加分类表单
  showAddCategoryForm() {
    this.setData({
      showAddCategoryForm: true,
      newCategory: {
        name: '',
        color: '#4CAF50'
      }
    });
  },

  // 隐藏添加分类表单
  hideAddCategoryForm() {
    this.setData({
      showAddCategoryForm: false
    });
  },

  // 新分类名称输入
  onNewCategoryNameInput(e) {
    this.setData({
      'newCategory.name': e.detail.value
    });
  },

  // 选择颜色
  selectColor(e) {
    const color = e.currentTarget.dataset.color;
    this.setData({
      'newCategory.color': color
    });
  },

  // 添加自定义分类
  async addCustomCategory() {
    const { newCategory, billType } = this.data;
    
    if (!newCategory.name.trim()) {
      app.showToast('请输入分类名称');
      return;
    }

    try {
      app.showLoading('添加中...');
      
      const categoryData = {
        name: newCategory.name.trim(),
        type: billType === 'expense' ? 2 : 1,
        color: newCategory.color,
        icon: newCategory.name.charAt(0)
      };

      const res = await app.request({
        url: '/categories',
        method: 'POST',
        data: categoryData
      });

      // 添加到分类列表
      const categories = [...this.data.categories, res];
      this.setData({
        categories,
        showAddCategoryForm: false
      });

      this.filterCategories();
      app.showToast('分类添加成功', 'success');
    } catch (error) {
      console.error('添加分类失败:', error);
      app.showToast('添加分类失败');
    } finally {
      app.hideLoading();
    }
  },

  // 日期选择
  onDateChange(e) {
    this.setData({
      billDate: e.detail.value
    });
  },

  // 备注输入
  onDescriptionInput(e) {
    this.setData({
      description: e.detail.value
    });
  },

  // 详细备注输入
  onRemarkInput(e) {
    this.setData({
      remark: e.detail.value
    });
  },

  // 检查是否可以提交
  get canSubmit() {
    const { amount, selectedCategory } = this.data;
    return amount && parseFloat(amount) > 0 && selectedCategory;
  },

  // 提交账单
  async onSubmit() {
    const { amount, selectedCategory, billDate, description, remark } = this.data;

    // 验证数据
    if (!amount || parseFloat(amount) <= 0) {
      app.showToast('请输入有效金额');
      return;
    }

    if (!selectedCategory) {
      app.showToast('请选择分类');
      return;
    }

    this.setData({ loading: true });

    try {
      const billData = {
        categoryId: selectedCategory.id,
        amount: parseFloat(amount),
        billDate: billDate + 'T00:00:00.000Z',
        description: description.trim() || null,
        remark: remark.trim() || null
      };

      await app.request({
        url: '/bills',
        method: 'POST',
        data: billData
      });

      app.showToast('账单保存成功', 'success');
      
      // 返回上一页或首页
      setTimeout(() => {
        const pages = getCurrentPages();
        if (pages.length > 1) {
          wx.navigateBack();
        } else {
          wx.switchTab({
            url: '/pages/index/index'
          });
        }
      }, 1000);

    } catch (error) {
      console.error('保存账单失败:', error);
      app.showToast(error.message || '保存失败，请重试');
    } finally {
      this.setData({ loading: false });
    }
  }
});
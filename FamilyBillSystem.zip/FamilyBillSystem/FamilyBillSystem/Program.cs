using FamilyBillSystem.Data;
using FamilyBillSystem.Services;
using FamilyBillSystem.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Http.Features;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.HttpOverrides;
using System.Security.Claims;

namespace FamilyBillSystem
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // ---------------- 日志配置 ----------------
            builder.Logging.ClearProviders();
            builder.Logging.AddConsole();
            builder.Logging.AddDebug();

            // ---------------- MySQL 配置 ----------------
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
            builder.Services.AddDbContext<AppDbContext>(options =>
                options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString),
                    mysqlOptions =>
                    {
                        mysqlOptions.EnableRetryOnFailure(
                            maxRetryCount: 5,
                            maxRetryDelay: TimeSpan.FromSeconds(30),
                            errorNumbersToAdd: null
                        );
                    })
                .EnableSensitiveDataLogging()
                .LogTo(Console.WriteLine, LogLevel.Information)
            );

            // ---------------- JWT 配置 ----------------
            var jwtKey = builder.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT Key未配置");
            var key = Encoding.UTF8.GetBytes(jwtKey);
            
            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = false;
                options.SaveToken = false;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = builder.Configuration["Jwt:Issuer"],
                    ValidateAudience = true,
                    ValidAudience = builder.Configuration["Jwt:Audience"],
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(2),
                    NameClaimType = ClaimTypes.NameIdentifier,
                    RoleClaimType = ClaimTypes.Role
                };
                
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        // 完全接管Token提取逻辑
                        var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
                        if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                        {
                            var token = authHeader.Substring(7).Trim();
                            Console.WriteLine($"[OnMessageReceived] 提取Token: 长度={token.Length}, 点数={token.Count(c => c == '.')}, 前50字符={token.Substring(0, Math.Min(50, token.Length))}");
                            context.Token = token;
                        }
                        
                        return Task.CompletedTask;
                    },
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception is SecurityTokenExpiredException)
                        {
                            context.Response.Headers.Add("Token-Expired", "true");
                            Console.WriteLine($"[JWT] Token已过期: {context.Exception.Message}");
                        }
                        else
                        {
                            Console.WriteLine($"[JWT] 认证失败: {context.Exception.Message}");
                            if (!string.IsNullOrEmpty(context.Request.Headers["Authorization"]))
                            {
                                var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
                                Console.WriteLine($"[JWT] Authorization头长度: {authHeader?.Length}, 内容前50字符: {authHeader?.Substring(0, Math.Min(50, authHeader?.Length ?? 0))}");
                            }
                        }
                        return Task.CompletedTask;
                    },
                    OnTokenValidated = context =>
                    {
                        var userId = context.Principal?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                        Console.WriteLine($"[JWT] Token验证成功 - 用户ID: {userId}");
                        return Task.CompletedTask;
                    }
                };
            });
            
            builder.Services.AddAuthorization();

            // ---------------- 邮件服务 ----------------
            builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("Email"));
            builder.Services.AddSingleton<EmailService>();

            // ---------------- 七牛云服务 ----------------
            builder.Services.Configure<QiniuSettings>(builder.Configuration.GetSection("Qiniu"));
            builder.Services.AddScoped<QiniuService>();

            // ---------------- AuthService ----------------
            builder.Services.AddScoped<AuthService>();
            builder.Services.AddHttpClient<AuthService>();

            // ---------------- CORS ----------------
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            builder.Services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
                options.KnownNetworks.Clear();
                options.KnownProxies.Clear();
            });

            // ---------------- Controllers & Swagger ----------------
            builder.Services.AddControllers();
            builder.Services.Configure<IISServerOptions>(options =>
            {
                options.MaxRequestBodySize = 10 * 1024 * 1024; // 10MB
            });
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // ---------------- HTTP 管道 ----------------
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseForwardedHeaders();
            app.UseHttpsRedirection();
            app.UseCors("AllowAll");
            
            // 请求日志中间件
            app.Use(async (context, next) =>
            {
                var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
                if (!string.IsNullOrEmpty(authHeader))
                {
                    var tokenPart = authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase) 
                        ? authHeader.Substring(7) 
                        : authHeader;
                    Console.WriteLine($"[请求] {context.Request.Method} {context.Request.Path}, Token长度: {tokenPart.Length}, Token前30字符: {tokenPart.Substring(0, Math.Min(30, tokenPart.Length))}");
                }
                await next();
            });
            
            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllers();

            // 初始化种子数据
            using (var scope = app.Services.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                await SeedData.Initialize(context);
            }

            app.Run();
        }
    }
}
